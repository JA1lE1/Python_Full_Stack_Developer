# -*- coding: utf-8 -*-
from init_route import *

if __name__ == '__main__':
	#10.108.17.182
	app.run(host='0.0.0.0',debug=True)
