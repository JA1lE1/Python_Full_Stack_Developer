#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name:test
   Author:jasonhaven
   date:18-8-16
-------------------------------------------------
   Change Activity:18-8-16:
-------------------------------------------------
"""
import keyword_extract

if __name__ == '__main__':
    print(keyword_extract.extract('',10,'lda',0,'chinese'))